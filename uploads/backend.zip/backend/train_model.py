import pandas as pd
import joblib
from xgboost import XGBClassifier

# ডেমো ডাটা দিয়ে মডেল ট্রেইন (আপনি পরে আসল ডাটা দিয়ে আপডেট করবেন)
data = {
    'syscall_count': [10, 500, 20, 600, 15],
    'network_egress': [0, 1, 0, 1, 0], # 0 = No, 1 = Yes
    'label': [0, 1, 0, 1, 0] # 0 = Benign, 1 = Malicious
}
df = pd.DataFrame(data)
X = df.drop('label', axis=1)
y = df['label']

model = XGBClassifier()
model.fit(X, y)
joblib.dump(model, 'scala_guard_model.pkl')
print("✅ scala_guard_model.pkl তৈরি হয়েছে!")

