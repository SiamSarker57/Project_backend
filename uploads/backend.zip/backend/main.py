import os, subprocess, joblib, re
from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

model = joblib.load('scala_guard_model.pkl')

@app.post("/analyze")
async def analyze(package_file: UploadFile = File(...)):
    # ১. ফাইল সেভ
    os.makedirs("uploads", exist_ok=True)
    path = f"uploads/{package_file.filename}"
    with open(path, "wb") as f: f.write(package_file.file.read())

    # ২. স্যান্ডবক্স (ডকার কমান্ড - আপনার পিসিতে ডকার ও ইমেজ থাকতে হবে)
    # subprocess.run(["docker", "run", ...]) # আসল ডকার কমান্ড এখানে হবে

    # ৩. ডেমো ফিচার এক্সট্রাকশন (লজিক অনুযায়ী)
    syscalls = 450 # ডেমো ভ্যালু
    net = 1
    
    # ৪. ML প্রেডিকশন
    pred = model.predict([[syscalls, net]])[0]
    score = 85 if pred == 1 else 15

    return {
        "risk_score": score,
        "label": "Malicious" if pred == 1 else "Benign",
        "ai_suggestion": "ক্ষতিকর আচরণ ধরা পড়েছে। বিকল্প প্যাকেজ ব্যবহার করুন।" if pred == 1 else "নিরাপদ।",
        "logs": ["Starting Sandbox...", "Capturing Syscalls...", "Network egress detected!"]
    }

